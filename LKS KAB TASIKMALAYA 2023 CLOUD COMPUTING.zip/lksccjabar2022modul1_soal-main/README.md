# LKS SMK Tingkat Provinsi Jawa Barat Bidang Cloud Computing - Soal Modul 1

`pdflatex --jobname=soal1 main.tex`
