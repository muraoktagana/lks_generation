# LKS SMK Tingkat Provinsi Jawa Barat Bidang Cloud Computing - Soal Modul 2

`pdflatex --jobname=soal2 main.tex`
