# LKS SMK Tingkat Provinsi Jawa Barat Bidang Cloud Computing - Soal Modul 3

`pdflatex --jobname=soal3 main.tex`
