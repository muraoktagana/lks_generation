# LKS SMK Tingkat Provinsi Jawa Barat Bidang Cloud Computing - Modul 1

This lambda function requires the following environment variables:
* `TABLE_NAME`: DynamoDB table name
